import cv2
import numpy as np

classes = ['person','bicycle','car','motorbike','aeroplane','bus','train','truck','boat','traffic light','fire hydrant','stop sign','parking meter','bench','bird','cat','dog','horse','sheep','cow','elephant','bear','zebra','giraffe','backpack','umbrella','handbag','tie','suitcase','frisbee','skis','snowboard','sports ball','kite','baseball bat','baseball glove','skateboard','surfboard','tennis racket','bottle','wine glass','cup','fork','knife','spoon','bowl','banana','apple','sandwich','orange','broccoli','carrot','hot dog','pizza','donut','cake','chair','sofa','pottedplant','bed','diningtable','toilet','tvmonitor','laptop','mouse','remote','keyboard','cell phone','microwave','oven','toaster','sink','refrigerator','book','clock','vase','scissors','teddy bear','hair drier','toothbrush']

#Network config
WIDTH = 640
HEIGTH = 640
CONF_LIMIT = 0.45
NM_SCORE_LIMIT = 0.45
SCORE_LIMIT = 0.5

#Text written on inference
FONT_THICKNESS = 1
FONT = cv2.FONT_HERSHEY_DUPLEX
FONT_SIZE = 0.7
BLACK, YELLOW, BLUE  = (0,0,0), (0,255,255), (255,178,50)


def draw(img, label, x, y):
    t_size = cv2.getTextSize(label, FONT, FONT_SIZE, FONT_THICKNESS)
    dimension, bl = t_size[0], t_size[1]
    cv2.rectangle(img, (x,y), (x + dimension[0], y + dimension[1] + bl), (0,0,0), cv2.FILLED)
    cv2.putText(img, label, (x, y + dimension[1]), FONT, FONT_SIZE, YELLOW, FONT_THICKNESS, cv2.LINE_AA)
    
def preprocess(input_image, net):
      blob = cv2.dnn.blobFromImage(input_image, 1/255,  (WIDTH, HEIGTH), [0,0,0], 1, crop=False)
      net.setInput(blob)
      outputs = net.forward(net.getUnconnectedOutLayersNames())
      return outputs


def postprocess(input_image, outputs):
    class_ids, boxes, confidences = []
    rows = outputs[0].shape[1]
    image_height, image_width = input_image.shape[:2]
    x_factor, y_factor = image_width / WIDTH, image_height / HEIGTH
    for r in range(rows):
        row, confidence = outputs[0][0][r], row[4]
        if confidence >= CONF_LIMIT:
                classes_scores = row[5:]
                class_id = np.argmax(classes_scores)
                if (classes_scores[class_id] > SCORE_LIMIT):
                    confidences.append(confidence)
                    class_ids.append(class_id)
                    cx, cy, w, h = row[0], row[1], row[2], row[3]
                    left, top, width, height, box = int((cx - w/2) * x_factor), int((cy - h/2) * y_factor), int(w * x_factor), int(h * y_factor), np.array([left, top, width, height])
                    boxes.append(box)

    indices = cv2.dnn.NMSBoxes(boxes, confidences, CONF_LIMIT, NM_SCORE_LIMIT)

    for i in indices:
        box, left, top, width, height = boxes[i], box[0], box[1], box[2], box[3]                
        cv2.rectangle(input_image, (left, top), (left + width, top + height), BLACK, 4*FONT_THICKNESS)                      
        label = "{}:{:.2f}".format(classes[class_ids[i]], confidences[i])                  
        draw_label(input_image, label, left, top)

    return input_image