# CoppeliaSim MyT

## Completed Tasks

- Task 1, 2, 3

## Requirements

- Python >= 3.0
- ROS 2
- CoppeliaSim

### Usage

1. Unzip the archive of the package folder `jorge_espinar_final_project.zip` in your workspace folder and build it by running `colcon build` from the workspace root `~/dev_ws`. 

2, Open a new terminal, source the workspace

```{bash}
source ~/dev_ws/install/setup.bash
```

3. To start CoppeliaSim, enter the following command in one of your terminals:

```{bash}
~/apps/CoppeliaSim_Edu_V4_3_0_Ubuntu20_04/coppeliaSim.sh
```

4. Then we need to start the bridge (before the simmulation), in order to do that we need to execute the following command:

```{bash}
ros2 launch thymioid main.launch device:="tcp:host=localhost;port=33333" simulation:=True name:=thymio0
```

5. Then we start the simmulation and execute the project.
```{bash}
ros2 launch thymio_example project.launch.py thymio_name:=thymio0
```

## Problems faced

1. The robot collides when have to continuing exploring the map

2. Cannot find the camera sensor very clearly

3. Once found, create a subscriber and access the information from it in order to generate real-time predictions over the images. (Here I got errors, I was able to do it but not in real time so it haven't been included in this code, but I show a picture of the scene in the report with predictions)

4. Robot collides with objects different from a wall
