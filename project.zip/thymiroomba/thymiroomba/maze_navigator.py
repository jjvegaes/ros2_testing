import rclpy
import numpy as np
import cv2
from cv_bridge import CvBridge

from thymiroomba.controller import ControllerNode
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Range, Image

from math import inf
from enum import Enum
import sys

class ThymioState(Enum):
    FORWARD = 1
    BACKUP = 2
    ROTATE = 3
    CURVE = 4
    ALIGN = 5
    DONE = 6
    
bridge = CvBridge()

class MazeNavigator(ControllerNode):
    # Period of the update timer, set based on update frequencies of proximity sensors (10Hz) and odom (20Hz)
    UPDATE_STEP = 1/20

    # Max range of the Thymio's proximity sensors
    OUT_OF_RANGE = 0.12

    # Target distance of the robot from the wall at the end of FORWARD
    TARGET_DISTANCE = OUT_OF_RANGE - 0.02

    # Minimum distance from the wall to be able to rotate in place
    TOO_CLOSE = 0.05

    # Target difference between the distance measured by the two distance sensors
    TARGET_ERROR = 0.001

    def __init__(self):
        super().__init__('maze_navigator', update_step=self.UPDATE_STEP)

        # Initialize the state machine
        self.current_state = None
        self.next_state = ThymioState.FORWARD
        self.elapsed_time = 0
        self.goal_seen = False
        self.goal_elapsed_time = 0

        # Subscribe to all proximity sensors at the same time
        self.front_sensors = ["center", "center_left", "center_right"]
        self.left_sensors = ["left", "center_left"]
        self.right_sensors = ["right", "center_right"]
        self.lateral_sensors = ["left", "right"]
        self.rear_sensors = ["rear_left", "rear_right"]
        self.proximity_sensors = self.front_sensors + self.lateral_sensors + self.rear_sensors
        self.proximity_distances = dict()
        self.proximity_subscribers = [
            self.create_subscription(Range, f'proximity/{sensor}', self.create_proximity_callback(sensor), 10)
            for sensor in self.proximity_sensors
        ]
        self.camera_subscriber = self.create_subscription(
            Image,
            'camera',
            self.camera_callback,
            10)

    def create_proximity_callback(self, sensor):
        # Create a callback function that has access to both the message and the name of the sensor that sent it
        def proximity_callback(msg):
            self.proximity_distances[sensor] = msg.range if msg.range >= 0.0 else inf
            
            self.get_logger().debug(
                f"proximity: {self.proximity_distances}",
                throttle_duration_sec=0.5 # Throttle logging frequency to max 2Hz
            )
        return proximity_callback
    
    def filter_red(self, img):
        # Red threshold
        red_lower_bound = (0, 175, 135)
        red_upper_bound = (15, 255, 255)

        blurred = cv2.GaussianBlur(img, (11, 11), 0)
        hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

        mask = cv2.inRange(hsv, red_lower_bound, red_upper_bound)
        mask = cv2.erode(mask, None, iterations=2)
        mask = cv2.dilate(mask, None, iterations=2)

        imask = mask > 0
        red = np.zeros_like(img, np.uint8)
        red[imask] = img[imask]

        return red, mask

    def camera_callback(self, msg):
        img = bridge.imgmsg_to_cv2(msg, "bgr8")
        img_red, mask = self.filter_red(img)
        red_count = cv2.countNonZero(mask)

        if red_count != 0:
            self.goal_seen = True
        
        if self.goal_seen and red_count == 0:
            self.goal_elapsed_time += self.update_step
        
        if self.goal_elapsed_time > 2.5:
            self.next_state = ThymioState.DONE
        
        cv2.imshow('IMAGE', img)
        cv2.imshow("IMAGE_RED", img_red)
        cv2.waitKey(3)

    def update_callback(self):
        if self.odom_pose is None or \
           len(self.proximity_distances) < len(self.proximity_sensors):
            return
        
        if self.next_state != self.current_state:
            self.get_logger().info(f"state_machine: transitioning from {self.current_state} to {self.next_state}")
            
            if self.next_state == ThymioState.FORWARD:
                self.stop()
            elif self.next_state == ThymioState.BACKUP:
                self.stop()
            elif self.next_state == ThymioState.ROTATE:
                self.stop()
            elif self.next_state == ThymioState.CURVE:
                self.stop()
            elif self.next_state == ThymioState.ALIGN:
                self.stop()
            elif self.next_state == ThymioState.DONE:
                self.stop()
            
            self.current_state = self.next_state
        
        # Call update code for the current state
        if self.current_state == ThymioState.FORWARD:
            self.update_forward()
        elif self.current_state == ThymioState.BACKUP:
            self.update_backup()
        elif self.current_state == ThymioState.ROTATE:
            self.update_rotate()
        elif self.current_state == ThymioState.CURVE:
            self.update_curve()
        elif self.current_state == ThymioState.ALIGN:
            self.update_align()
        elif self.current_state == ThymioState.DONE:
            self.update_done()
    
    def is_aligned(self):
        # check if the robot is aligned with the wall
        if abs(abs(self.proximity_distances["center_left"]) - abs(self.proximity_distances["center_right"])) < self.TARGET_ERROR:
            return True
        else:
            return False
    
    def update_forward(self):
        # Check if there is a front wall
        if self.proximity_distances["center"] < self.TARGET_DISTANCE:
            self.next_state = ThymioState.BACKUP
            return
        elif self.proximity_distances["right"] > self.TARGET_DISTANCE:
            self.next_state = ThymioState.CURVE
            return

        # Just move forward with constant velocity
        cmd_vel = Twist() 
        cmd_vel.linear.x  = 0.3 # [m/s]
        cmd_vel.angular.z = 0.0 # [rad/s]
        self.vel_publisher.publish(cmd_vel)

    def update_backup(self):
        # Check if the robot didn't stop fast enough and hit the wall
        if all(self.proximity_distances[sensor] > self.TOO_CLOSE for sensor in self.front_sensors):
            self.next_state = ThymioState.ROTATE
            return
            
        # Slowly back up to clear the obstacle
        cmd_vel = Twist() 
        cmd_vel.linear.x  = -0.1 # [m/s]
        cmd_vel.angular.z =  0.0 # [rad/s]
        self.vel_publisher.publish(cmd_vel)
    
    def update_rotate(self):
        self.elapsed_time += self.update_step

        if self.elapsed_time > 2.5:
            self.next_state = ThymioState.FORWARD
            self.elapsed_time = 0
            return
        
        cmd_vel = Twist() 
        cmd_vel.linear.x  = 0.0 # [m/s]
        cmd_vel.angular.z = 1.0 # [rad/s]
        self.vel_publisher.publish(cmd_vel)
    
    def update_curve(self):
        if any(self.proximity_distances[sensor] <= self.TARGET_DISTANCE for sensor in self.right_sensors):
            self.next_state = ThymioState.ALIGN
            return
        
        # Curve forward with constant velocity
        cmd_vel = Twist() 
        cmd_vel.linear.x  = 0.1 # [m/s]
        cmd_vel.angular.z = -1.0 # [rad/s]
        self.vel_publisher.publish(cmd_vel)

    def update_align(self):
        if self.is_aligned:
            self.next_state = ThymioState.FORWARD
            return

        cmd_vel = Twist() 
        cmd_vel.linear.x  = 0.0 # [m/s]
        cmd_vel.angular.z = 0.1 # [rad/s]
        self.vel_publisher.publish(cmd_vel)
    
    def update_done(self):
        # Victory dance
        cmd_vel = Twist()
        cmd_vel.linear.x = 0.0
        cmd_vel.angular.z = 6.0
        self.vel_publisher.publish(cmd_vel)

def main():
    # Initialize the ROS client library
    rclpy.init(args=sys.argv)
    
    # Create an instance of your node class
    node = MazeNavigator()
    node.start()
    
    # Keep processings events until someone manually shuts down the node
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    
    # Ensure the Thymio is stopped before exiting
    node.stop()


if __name__ == '__main__':
    main()